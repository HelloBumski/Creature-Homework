public class Goblin extends Creature
{
    @Override
    // Returns the damage done by the Creature
    public float attack()
    {

        // 40% chance of missing
        if (Rand.randomInt(0, 10) < 4) {
            action = name + " missed!";
            return 0;
        }

        // otherwise, do damage between 10-25
        float power = Rand.randomFloat(10, 25);
        action = name + " attacked with power " + power + "!";
        return power;
    }

    @Override
    public void defend(float incomingPower)
    {
        // 50 % chance of reducing damage taken
        if (Rand.randomInt(0, 10) < 5)
        {
            incomingPower = incomingPower * 0.6f;
            action = name + " defended and reduced damage taken to " + incomingPower;
        }
        else
        {
            action = name + " did not defend.";
        }

        health -= incomingPower;
    }
}
