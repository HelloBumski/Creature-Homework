public class BattleSystem
{
    public void battle(Creature troglodyte, Creature gremlin, Creature goblin)
    {
        while (troglodyte.health > 0 && gremlin.health > 0 && goblin.health > 0)
        {
            float attackPower = troglodyte.attack();
            gremlin.defend(attackPower);
            goblin.defend(attackPower);
            System.out.println(troglodyte.readAction());
            System.out.println(gremlin.readAction());
            System.out.println(goblin.readAction());

            System.out.println(troglodyte);
            System.out.println(gremlin);
            System.out.println(goblin);
            System.out.println();

            // swap turns
            Creature temp = troglodyte;
            troglodyte = gremlin;
            gremlin = goblin;
            goblin = temp;
        }
    }
}
