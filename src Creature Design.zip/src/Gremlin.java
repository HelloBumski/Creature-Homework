public class Gremlin extends Creature
{
    @Override
    // Returns the damage done by the Creature
    public float attack()
    {
        // 50% chance of missing
        if (Rand.randomInt(0, 10) < 5) {
            action = name + " missed!";
            return 0;
        }

        // otherwise, do damage between 10-20
        float power = Rand.randomFloat(10, 20);
        action = name + " attacked with power " + power + "!";
        return power;
    }

    @Override
    public void defend(float incomingPower)
    {
        // 10 % chance of reducing damage taken
        if (Rand.randomInt(0, 10) < 3) {
            incomingPower = incomingPower * 0.5f;
            action = name + " defended and reduced damage taken to " + incomingPower;
        }
        else
        {
            action = name + " did not defend.";
        }

        health -= incomingPower;
    }
}
