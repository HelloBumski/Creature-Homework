public class Main {
    public static void main(String[] args) {

        // set up the creatures
        Creature troglodyte = new Troglodyte();
        Creature gremlin = new Gremlin();
        Creature goblin = new Goblin();

        troglodyte.name = "Troglodyte";
        troglodyte.health = 100;

        gremlin.name = "Gremlin";
        gremlin.health = 100;

        goblin.name = "Goblin";
        goblin.health = 100;

        // set up the battle
        BattleSystem battleSystem = new BattleSystem();

        // run the battle
        battleSystem.battle(troglodyte, gremlin, goblin);
    }
}
