public class Troglodyte extends Creature
{
    @Override
    // Returns the damage done by the Creature
    public float attack()
    {
        // 30% chance of missing
        if (Rand.randomInt(0, 10) < 3) {
            action = name + " missed!";
            return 0;
        }

        // otherwise, do damage between 10-30
        float power = Rand.randomFloat(10, 30);
        action = name + " attacked with power " + power + "!";
        return power;
    }

    @Override
    public void defend(float incomingPower)
    {
        // 80 % chance of reducing damage taken
        if (Rand.randomInt(0, 10) < 8) {
            incomingPower = incomingPower * 0.9f;
            action = name + " defended and reduced damage taken to " + incomingPower;
        }
        else
        {
            action = name + " did not defend.";
        }

        health -= incomingPower;
    }
}
